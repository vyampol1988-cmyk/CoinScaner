package com.coinscanner.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 14, 17)
    private val panel = Color.rgb(24, 26, 32)
    private val yellow = Color.rgb(240, 185, 11)
    private val green = Color.rgb(14, 203, 129)
    private val red = Color.rgb(246, 70, 93)
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private var activeTab = "Рынок"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        loadMarket()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(bg)
        }
        header.addView(label("◈", 28f, yellow, true))
        header.addView(label("Coin Scanner", 22f, Color.WHITE, true))
        val refresh = Button(this).apply {
            text = "Обновить"
            setTextColor(yellow)
            setBackgroundColor(panel)
            setOnClickListener { loadMarket() }
        }
        header.addView(refresh, LinearLayout.LayoutParams(-2, dp(42)).apply {
            gravity = Gravity.CENTER_VERTICAL
            leftMargin = dp(8)
        })
        root.addView(header)

        val subtitle = label("РЫНОК USDT  •  СИГНАЛЫ И ИМПУЛЬС", 11f, Color.LTGRAY, true)
        subtitle.setPadding(dp(16), dp(4), dp(16), dp(8))
        root.addView(subtitle)

        status = label("Подключаемся к Binance…", 13f, yellow)
        status.setPadding(dp(16), dp(6), dp(16), dp(6))
        root.addView(status)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(12))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(panel)
            gravity = Gravity.CENTER
        }
        listOf("Главная", "Рынок", "Прогнозы", "Новости", "Избранное").forEach { tab ->
            val b = TextView(this).apply {
                text = tab
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(if (tab == activeTab) yellow else Color.LTGRAY)
                setPadding(dp(5), dp(14), dp(5), dp(14))
                setOnClickListener {
                    activeTab = tab
                    if (tab == "Новости") {
                        content.removeAllViews()
                        content.addView(label("Новости и анализ событий", 20f, Color.WHITE, true))
                        content.addView(label("Новостной источник будет подключён следующим этапом. Сейчас приложение показывает рыночные данные Binance; новостной прогноз пока не активен.", 14f, Color.LTGRAY))
                    } else if (tab == "Прогнозы") {
                        loadMarket(true)
                    } else {
                        loadMarket()
                    }
                    buildScreenNavUpdate(nav)
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun buildScreenNavUpdate(nav: LinearLayout) {
        for (i in 0 until nav.childCount) {
            val v = nav.getChildAt(i) as TextView
            v.setTextColor(if (v.text.toString() == activeTab) yellow else Color.LTGRAY)
        }
    }

    private fun loadMarket(predictionsOnly: Boolean = activeTab == "Прогнозы") {
        status.text = "Обновляем рыночные данные…"
        thread {
            try {
                val connection = (URL("https://api.binance.com/api/v3/ticker/24hr").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000
                    readTimeout = 12000
                    requestMethod = "GET"
                }
                val data = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val arr = JSONArray(data)
                val rows = mutableListOf<Coin>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val symbol = obj.optString("symbol")
                    if (!symbol.endsWith("USDT") || symbol.contains("UPUSDT") || symbol.contains("DOWNUSDT") ||
                        symbol.contains("BULLUSDT") || symbol.contains("BEARUSDT")) continue
                    val price = obj.optString("lastPrice").toDoubleOrNull() ?: continue
                    val change = obj.optString("priceChangePercent").toDoubleOrNull() ?: 0.0
                    val volume = obj.optString("quoteVolume").toDoubleOrNull() ?: 0.0
                    rows.add(Coin(symbol.removeSuffix("USDT"), price, change, volume))
                }
                rows.sortByDescending { it.volume }
                val filtered = if (predictionsOnly) rows.filter { it.change >= 3.0 || it.change <= -3.0 }
                    .sortedByDescending { kotlin.math.abs(it.change) }.take(40)
                else rows.take(100)
                runOnUiThread {
                    content.removeAllViews()
                    if (filtered.isEmpty()) content.addView(label("Пока нет выраженных сигналов. Попробуйте обновить позже.", 15f, Color.LTGRAY))
                    filtered.forEach { addCoinCard(it) }
                    status.text = "Binance • ${filtered.size} монет • обновлено сейчас"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Не удалось загрузить данные. Проверьте интернет и нажмите «Обновить»."
                    content.removeAllViews()
                    content.addView(label("Ошибка соединения с Binance.", 17f, red, true))
                    content.addView(label("Это стартовая сборка. Новости и расширенный прогноз будут добавлены отдельным этапом.", 14f, Color.LTGRAY))
                }
            }
        }
    }

    private fun addCoinCard(coin: Coin) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackgroundColor(panel)
        }
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(label("${coin.symbol} / USDT", 16f, Color.WHITE, true))
        left.addView(label("Объём: ${formatVolume(coin.volume)} USDT", 11f, Color.LTGRAY))
        line.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        right.addView(label(formatPrice(coin.price), 15f, Color.WHITE, true))
        val color = if (coin.change >= 0) green else red
        right.addView(label(String.format(Locale.US, "%+.2f%%", coin.change), 14f, color, true))
        line.addView(right)
        card.addView(line)
        val signal = when {
            coin.change >= 5 -> "Сильный импульс вверх • повышенная волатильность"
            coin.change >= 1.5 -> "Положительный импульс за 24 ч"
            coin.change <= -5 -> "Сильный импульс вниз • высокий риск"
            coin.change <= -1.5 -> "Отрицательный импульс за 24 ч"
            else -> "Нет сильного движения за 24 ч"
        }
        card.addView(label(signal, 11f, if (coin.change >= 1.5) green else if (coin.change <= -1.5) red else Color.LTGRAY))
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun formatPrice(v: Double): String =
        if (v >= 1) String.format(Locale.US, "%.4f", v) else String.format(Locale.US, "%.8f", v)

    private fun formatVolume(v: Double): String = when {
        v >= 1_000_000_000 -> String.format(Locale.US, "%.2fB", v / 1_000_000_000)
        v >= 1_000_000 -> String.format(Locale.US, "%.2fM", v / 1_000_000)
        v >= 1_000 -> String.format(Locale.US, "%.1fK", v / 1_000)
        else -> String.format(Locale.US, "%.0f", v)
    }

    data class Coin(val symbol: String, val price: Double, val change: Double, val volume: Double)
}
